function varargout = lychse(varargin)
% LYCHSE M-file for lychse.fig
%      LYCHSE, by itself, creates a new LYCHSE or raises the existing
%      singleton*.
%
%      H = LYCHSE returns the handle to a new LYCHSE or the handle to
%      the existing singleton*.
%
%      LYCHSE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LYCHSE.M with the given input arguments.
%
%      LYCHSE('Property','Value',...) creates a new LYCHSE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pjjmage11_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to lychse_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help lychse

% Last Modified by GUIDE v2.5 06-Jan-2020 14:05:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @lychse_OpeningFcn, ...
                   'gui_OutputFcn',  @lychse_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before lychse is made visible.
function lychse_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to lychse (see VARARGIN)

% Choose default command line output for lychse
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes lychse wait for user response (see UIRESUME)
% uiwait(handles.figure1);



setappdata(handles.figure1,'img_src',0);
% set(handles.tbl_save,'Enable','off');
set(handles.m_file_save,'Enable','off');
set(handles.m_image_analysis,'Enable','off');

set(handles.popupmenu1,'Enable','off');
% --- Outputs from this function are returned to the command line.
function varargout = lychse_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --------------------------------------------------------------------
function m_file_open_Callback(hObject, eventdata, handles)
% hObject    handle to m_file_open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,pathname]=uigetfile(...
    {'*.bmp;*.jpg;*.png;*.jpeg','Image Files(*.bmp, *.jpg, *.png, *.jpeg) ';...
    '*.*',           'ALL Files(*.*)'},...
    'Pick an image');
if isequal(filename,0)||isequal(pathname,0),
    return;
end

set(handles.popupmenu1,'Value',1);
axes(handles.axes_dst);
cla;
axis([0 256 0 256]);
xlabel(' '), ylabel(' ');
axis off;
axes(handles.axes_src);
cla;
fpath=[pathname filename];
img_src=imread(fpath);
imshow(img_src);
setappdata(handles.figure1,'img_src' ,img_src);
% set(handles.tbl_save,'Enable','on');
set(handles.m_file_save,'Enable','on');
set(handles.m_image_analysis,'Enable','on');

set(handles.popupmenu1,'Enable','off');
msgbox('��������ƭ��,q1321814823��')
% --------------------------------------------------------------------
function m_file_save_Callback(hObject, eventdata, handles)
% hObject    handle to m_file_save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img_src=getappdata(handles.figure1,' img_src');
[filename,pathname]=uiputfile({'*.bmp','BMP files';'*.jpg','JPG files'},'Save as an Image');
if isequal(filename,0)||isequal(pathname,0)
    return;%������ˡ�ȡ����
else
    fpath=fullfile(pathname,filename);
end
img_src=getappdata(handles.figure1,'img_src');
imwrite(img_src,fpath);
% --------------------------------------------------------------------
function m_file_exit_Callback(hObject, eventdata, handles)
% hObject    handle to m_file_exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Button=questdlg('������˹رհ�ť����Ҫ�رմ����𣿣�');
switch Button
    case 'Yes'
    close(handles.figure1);
    otherwise
     
end

% --------------------------------------------------------------------
function m_file_Callback(hObject, eventdata, handles)
% hObject    handle to m_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function m_image_Callback(hObject, eventdata, handles)
% hObject    handle to m_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function m_image_analysis_Callback(hObject, eventdata, handles)
% hObject    handle to m_image_analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.m_image_analysis,'Enable','off');
set(handles.popupmenu1,'Enable','on');
% clear;
% clc;
% RGB=imread(img_src);
RGB=getappdata(handles.figure1,'img_src' );
%  RGB= imrotate(RGB,90,'crop');
% figure,imshow(RGB);     title('RGB')
GRAY=rgb2gray(RGB);
% figure,imshow(GRAY);    title('GRAY')
threshold=graythresh(GRAY);
BW=im2bw(GRAY,threshold);
% figure,imshow(BW);      title('BW')
BW=~BW;
% figure,imshow(BW);      title('~BW')
BW=bwmorph(BW,'thin',Inf);
% figure,imshow(BW);      title('BWMORPH')
[M,N]=size(BW);
[H,T,R] = hough(BW);
% 
%        imshow(H,[],'XData',T,'YData',R,'InitialMagnification','fit');
%        xlabel('\theta'), ylabel('\rho');
%        axis on, axis normal, hold on;
        P  = houghpeaks(H,1,'threshold',ceil(0.3*max(H(:))));
%        x = T(P(:,2)); 
%        y = R(P(:,1));
%        plot(x,y,'s','color','white');
%        Find lines and plot them
       lines = houghlines(BW,T,R,P,'FillGap',5,'MinLength',7);
       hold on;
axes(handles.axes_dst);
        imshow(BW), hold on
       max_len = 0;
       for k = 1:length(lines)
         xy = [lines(k).point1; lines(k).point2];
%          theta=[lines(k).thetaAngle];
         plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');
         % plot beginnings and ends of lines
%          plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
%          plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');
         % determine the endpoints of the longest line segment 
         len = norm(lines(k).point1 - lines(k).point2);
         if ( len > max_len)
           max_len = len;
           xy_long = xy;
         end
       end
       % highlight the longest line segment
       plot(xy_long(:,1),xy_long(:,2),'LineWidth',2,'Color','cyan');       
       k=(xy(2,2)-xy(1,2))/(xy(2,1)-xy(1,1));
theta=pi/2+atan(k);
       if((xy(1,1)+xy(2,1))/2<=N/2)
%                  s=1;  
                 
       else
%                s=2;
                   
       end
           
           myformat = '%g \n';
% open the file with permission to append
fid = fopen('yibiaoshishu.txt','a');
% write values at end of file

% close the file 
fclose(fid);
%        disp (theta);
%        disp (q);
%        disp (shishu);
% set(handles.text_k,'String',num2str(k));
set(handles.text_q,'String','�����ƣ�Q1321814823');
set(handles.text_shishu,'String','�����ƣ�Q1321814823');
% --- Executes on button press in chose_a_picture.
function chose_a_picture_Callback(hObject, eventdata, handles)
% hObject    handle to chose_a_picture (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
m_file_open_Callback(hObject, eventdata, handles);

% --- Executes on button press in start_analysis.
function start_analysis_Callback(hObject, eventdata, handles)
% hObject    handle to start_analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
m_image_analysis_Callback(hObject, eventdata, handles);



% --------------------------------------------------------------------
function m_view_Callback(hObject, eventdata, handles)
% hObject    handle to m_view (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function m_view_code_Callback(hObject, eventdata, handles)
% hObject    handle to m_view_code (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on mouse press over figure background.
function figure1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes during object creation, after setting all properties.
function axes_bg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes_bg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes_bg

% --------------------------------------------------------------------
function m_view_record_Callback(hObject, eventdata, handles)
% hObject    handle to m_view_record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

num=get(handles.popupmenu1,'value');
RGB=getappdata(handles.figure1,'img_src' );
GRAY=rgb2gray(RGB);
% figure,imshow(GRAY);    title('GRAY')
threshold=graythresh(GRAY);
BW=im2bw(GRAY,threshold);

% figure,imshow(BW);      title('BW')
BW=~BW;
% figure,imshow(BW);      title('~BW')
BW=bwmorph(BW,'thin',Inf);
% figure,imshow(BW);      title('BWMORPH')
[M,N]=size(BW);
[H,T,R] = hough(BW);
%        imshow(H,[],'XData',T,'YData',R,'InitialMagnification','fit');
%        xlabel('\theta'), ylabel('\rho');
%        axis on, axis normal, hold on;
        P  = houghpeaks(H,1,'threshold',ceil(0.3*max(H(:))));
%        x = T(P(:,2)); 
%        y = R(P(:,1));
%        plot(x,y,'s','color','white');
       % Find lines and plot them
       lines = houghlines(BW,T,R,P,'FillGap',5,'MinLength',7);
       hold on;

axes(handles.axes_dst);

    switch num
        case 1                     %��ʾ��ֵ�Ա�Ч��
           web www.wobishe.com 
        case 2                     %��ʾԭͼ�Ա�Ч��
            msgbox('�����ƣ�Դ����ϵQ609553134')
        case 3                      %��ʾ�Զ�ͼ��
            cla;
            axis([0 256 0 256]);
            xlabel(' '), ylabel(' ');
            imshow(GRAY);           
            axis off;
        case 4                      %��ʾ��ֵͼ��
            cla;
            axis([0 256 0 256]);
            xlabel(' '), ylabel(' ');
            imshow(BW);             
            axis off;
        case 5                      %��ʾrho-thteta�任��
            cla;
            imshow(H,[],'XData',T,'YData',R,'InitialMagnification','fit');
            xlabel('\theta'), ylabel('\rho');
            axis on, axis normal, hold on;
            P  = houghpeaks(H,1,'threshold',ceil(0.3*max(H(:))));
            x = T(P(:,2)); 
            y = R(P(:,1));
            plot(x,y,'s','color','white');
            axis([-80 80 -300 300]);
            
    otherwise
end;

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
